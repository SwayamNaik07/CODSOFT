/*
 * Name: Jiban Jyoti Rout
 * Registration Number: 2241018154
 * Sec-2241039
 * Branch-BTECH-CSE
 * Date- 06/02/2023
 */

import java.util.Scanner;
public class affinechiper {
    static int MultiplicativeInverse(int key1, int limit) {
        for (int l = 0; l < limit; l++) {
            if ((key1 * l) % limit == 1) {
                return l;
            }
        }
        return -1;
    }
    static String Encryption(String plainText, String[] alphabets, int key1, int key2){
        String chipperText = "";
        for (int i = 0; i < plainText.length(); i++){
            if ((plainText.charAt(i)+"").equals(" ")){
                chipperText += " ";
            }

            for (int j = 0; j < alphabets.length; j++){
                 if ((plainText.charAt(i)+"").equals(alphabets[j])){
                    int encp = (j * key1 + key2)%26;
                    chipperText += alphabets[encp].toUpperCase();
                    //                    break;
                }
            }
        }
        return chipperText;
    }
    static String Decryption(String chipperText, String[] alphabets, int key1, int key2, int multiplicativeInverseOfKey1) {
        String decpPlainText = "";
        for (int i = 0; i < chipperText.length(); i++) {
            if ((chipperText.charAt(i)+"").equals(" ")){
                decpPlainText += " ";
            }
            for (int j = 0; j < alphabets.length; j++) {
                if ((chipperText.charAt(i) + "").toLowerCase().equals(alphabets[j])) {
//                        System.out.println(j);
                    if ((((j - key2) * multiplicativeInverseOfKey1) % alphabets.length) > 0) {
                        int decp = ((j - key2) * multiplicativeInverseOfKey1) % alphabets.length;
                        decpPlainText += alphabets[decp];
                    } else if ((((j - key2) * multiplicativeInverseOfKey1) % alphabets.length) <= 0) {
                        int decp = (((j - key2) + alphabets.length) * multiplicativeInverseOfKey1) % alphabets.length;
                        decpPlainText += alphabets[decp];
                    }
//                    break;
                }
            }
        }
        return decpPlainText;
    }


    public static void main(String[] args) {
        // Initialization
        Scanner input = new Scanner(System.in);
        System.out.println("---------Alice---------");
        System.out.print("Message: ");
        String plainText = input.nextLine();
        System.out.print("Enter the two secret keys (separated by a space): ");
        String keys = input.nextLine();
        int key1 = Integer.parseInt(keys.split(" ")[0]);
        int key2 = Integer.parseInt(keys.split(" ")[1]);
        String a = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z";
        String[] alphabets = a.split(",");
        int multiplicativeInverseOfKey1 = MultiplicativeInverse(key1, alphabets.length);

        // Now let's create the chipper text
        String chipperText = Encryption(plainText, alphabets, key1, key2);

        if (chipperText.length() > 0) {
            System.out.println("---------Bob---------");
            System.out.println("Hey Bob, this is Alice and the two secret keys to decrypt " + chipperText + " is: " + key1 + " and " + key2);
            System.out.print("key1 = ");
            int newKey1 = input.nextInt();
            System.out.print("key2 = ");
            int newKey2 = input.nextInt();
            String decpPlainText = Decryption(chipperText, alphabets, newKey1, newKey2, multiplicativeInverseOfKey1);
            System.out.println("Alice is saying: " + decpPlainText);
        }

    }
}

